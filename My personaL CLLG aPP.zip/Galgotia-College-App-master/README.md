# Galgotia-College-App
 INTRODUCTION:


GALGOTIAS COLLEGE ANDROID APP

This is a College App Which is designed for College purposes like showing introduction about college, showing various important Notices, Ebook for providing study materials to its students, A gallery for College Related Images, Faculty Details of every department and many more. Basically this app is Prototype for our College App.

We developed this Application using JAVA and XML and FIREBASE for Database Connectivity.

We Implemented This Application using ANDROID STUDIO.

There are two apps : USER APP and  ADMIN APP.

![image](https://user-images.githubusercontent.com/64531454/160920151-63a7dd66-a90b-44d8-8fa3-c2eb72d97367.png)
![image](https://user-images.githubusercontent.com/64531454/160920300-1b8be8bf-9c3a-46c1-8eef-4ed354daa8eb.png)
![image](https://user-images.githubusercontent.com/64531454/160920370-4705a9bf-3ce1-4e8a-99d7-6005ff817f82.png)
![image](https://user-images.githubusercontent.com/64531454/160920475-f0ac7761-fc50-410a-ad4c-f8093d21df55.png)
![image](https://user-images.githubusercontent.com/64531454/160920502-48352de1-3d22-4587-b67b-e0eeed6012b0.png)
![image](https://user-images.githubusercontent.com/64531454/160920532-f2aa40f9-7d25-4b44-9aa9-62eaad684c63.png)
![image](https://user-images.githubusercontent.com/64531454/160920572-381e333e-3bb0-4d2d-9d0e-16b0e959e0ad.png)
![image](https://user-images.githubusercontent.com/64531454/160920615-62c5f391-6e91-45bb-a588-e4b6aa605fb6.png)
